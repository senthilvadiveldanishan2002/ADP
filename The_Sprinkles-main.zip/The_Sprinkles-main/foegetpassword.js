function matchPassword() {  
    var pw1 = document.getElementById("pswd1");  
    var pw2 = document.getElementById("pswd2");  
    if(pw1 = pw2)  
    {   
      alert("Password created successfully");  
    } else {  
      alert("Passwords did not match");  
    }  
  } 
  form.addEventListener('submit',function(e) {
    e.preventDefault();

    checkRequired([ pswd1, pswd2]);
    checkLength(password,6,25);
    checkPasswordMatch(password, password2);
}); 