
const { request } = require("express");
const express=require("express");
var cors = require('cors');
const app= express();
const mongoose=require("mongoose");
app.use(express.json());
app.use(cors()); 
const {schema}=mongoose;
// const axios = require('axios')
app.use(express.urlencoded({ extended: true }));


// db create
mongoose.connect("mongodb://localhost:27017/regi").then
((db)=>{
        console.log("db connet");
    })
 .catch((err) =>{
        console.log("err");
    })




const  Sch= {
    username:String,
    email:String,
    password:String,
    password2:String
}
const monmodel=mongoose.model("customorsdetails",Sch)



app.post("/customorsdata",async(req,res)=>{
    console.log("inside post");

    const data=new monmodel({
        username:req.body.username,
        email:req.body.email,
        password:req.body.password,
        password2:req.body.password2
    });
    const val=await data.save();

    });


// getall

// app.get("/mongotonodefulldata",(req,res)=>{

//     monmodel.find((err,val)=>{
//         if(err){
//             console.log(err)
//         }else{
//             res.json(val)
//         }

//     })
// })

// app.put("/update", async (req, res) => {
//     let upname = req.params.name;
//     let upemail = req.body.email;
//     let upaddress = req.body.address;
//     let upphoneNo = req.body.phoneNo;
  
//     monmodel.findOneAndUpdate({ name: upname  }, { $set: { email: upemail, address: upaddress, phoneNo: upphoneNo} },
//         { new: true }, (err, data) => {
//             if (err) {
//                 res.send("Error")
//             } else {
//                 if (data == null) {
//                     res.send("nothing found")
//                 } else {
//                     res.send(data)
//                 }
//             }

//         })
// })

// app.listen(2022,()=>{
//     console.log("port 2001 runing");

// });



// app.delete('/del',function(req,res){
//     let dltname=req.params.name;
//     monmodel.findOneAndDelete(({name:dltname}),function(err,does){
//         if(err)
//         {
//             res.send("Errorr")
//         }
//         else{
//             if(does==null)
//             {
//                 res.send("wrong id")
//             }
//             else
//             {
//                 res.send("deleted");
//             }
//         }
//     })
// })

app.listen(2000, () => {
    console.log("on port 2020");
})
